# Jordan Belinsky Resume/CV Website
A redesign of my old personal hub website, centered around the main purpose of being an online resume/cv outside of LinkedIn.

For information regarding my personal projects, please visit my development brand website at <a href="http://designslate.ca">DesignSlate</a>, or the repository <a href="https://github.com/jordanbelinsky/designslate-web">here</a>.
